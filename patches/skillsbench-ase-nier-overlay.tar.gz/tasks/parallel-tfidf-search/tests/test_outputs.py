#!/usr/bin/env python3
"""
Tests for Parallel TF-IDF Implementation

Tests correctness and performance of the parallel implementation.
"""

import random
import sys
import time

import pytest

sys.path.insert(0, "/root/workspace")

from document_generator import generate_corpus
from sequential import (
    batch_search_sequential,
    build_tfidf_index_sequential,
)


class TestParallelImplementation:
    """Test that parallel implementation exists and has correct interface."""

    def test_parallel_solution_exists(self):
        """Test that parallel_solution.py exists and can be imported."""
        try:
            from parallel_solution import (
                batch_search_parallel,  # noqa: F401
                build_tfidf_index_parallel,  # noqa: F401
            )
        except ImportError as e:
            pytest.fail(f"Could not import parallel_solution: {e}")


class TestCorrectnessSmall:
    """Test correctness with small dataset."""

    @pytest.fixture(scope="class")
    def small_corpus(self):
        """Generate small test corpus."""
        return generate_corpus(1000, seed=42)

    @pytest.fixture(scope="class")
    def sequential_index(self, small_corpus):
        """Build sequential index for comparison."""
        return build_tfidf_index_sequential(small_corpus)

    def test_idf_values_match(self, small_corpus, sequential_index):
        """Test that IDF values match."""
        from parallel_solution import build_tfidf_index_parallel

        para_result = build_tfidf_index_parallel(small_corpus, num_workers=4)

        for term in sequential_index.index.vocabulary:
            seq_idf = sequential_index.index.idf.get(term, 0)
            para_idf = para_result.index.idf.get(term, 0)
            assert abs(seq_idf - para_idf) < 1e-6, f"IDF mismatch for term '{term}': {seq_idf} vs {para_idf}"

    def test_search_results_match(self, small_corpus, sequential_index):
        """Test that search results match."""
        from parallel_solution import batch_search_parallel, build_tfidf_index_parallel

        para_result = build_tfidf_index_parallel(small_corpus, num_workers=4)

        queries = ["machine learning algorithm", "database optimization", "clinical trial treatment"]

        seq_results = batch_search_sequential(queries, sequential_index.index, top_k=10, documents=small_corpus)
        para_results, _ = batch_search_parallel(queries, para_result.index, top_k=10, num_workers=4, documents=small_corpus)

        for i, (seq_res, para_res) in enumerate(zip(seq_results, para_results)):
            assert len(seq_res) == len(para_res), f"Different result count for query {i}"
            for j, (s, p) in enumerate(zip(seq_res, para_res)):
                assert s.doc_id == p.doc_id, f"Doc ID mismatch for query {i}, result {j}"
                assert abs(s.score - p.score) < 1e-6, f"Score mismatch for query {i}, result {j}"


class TestPerformanceIndexing:
    """Test index building performance."""

    @pytest.fixture(scope="class")
    def perf_corpus(self):
        """Generate corpus for performance testing."""
        return generate_corpus(5000, seed=789)

    def test_index_speedup(self, perf_corpus):
        """Test that parallel indexing achieves speedup."""
        from parallel_solution import build_tfidf_index_parallel

        # Sequential baseline
        start = time.perf_counter()
        build_tfidf_index_sequential(perf_corpus)
        seq_time = time.perf_counter() - start

        # Parallel with 4 workers
        start = time.perf_counter()
        build_tfidf_index_parallel(perf_corpus, num_workers=4)
        para_time = time.perf_counter() - start

        speedup = seq_time / para_time

        print("\nIndex Building Performance:")
        print(f"  Sequential: {seq_time:.2f}s")
        print(f"  Parallel (4 workers): {para_time:.2f}s")
        print(f"  Speedup: {speedup:.2f}x")

        # Require at least 1.5x speedup
        assert speedup >= 1.5, f"Insufficient speedup: {speedup:.2f}x (required: 1.5x)"


class TestPerformanceSearch:
    """Test batch search performance."""

    @pytest.fixture(scope="class")
    def search_setup(self):
        """Set up corpus and index for search testing."""
        corpus = generate_corpus(5000, seed=101)

        from parallel_solution import build_tfidf_index_parallel

        index_result = build_tfidf_index_parallel(corpus, num_workers=4)

        # Generate variable-length queries
        random.seed(202)
        base_terms = [
            "machine",
            "learning",
            "algorithm",
            "neural",
            "network",
            "database",
            "optimization",
            "performance",
            "clinical",
            "trial",
            "market",
            "analysis",
            "investment",
            "research",
            "methodology",
        ]

        queries = []
        for _ in range(1000):
            length = random.randint(1, 20)
            query = " ".join(random.choices(base_terms, k=length))
            queries.append(query)

        return corpus, index_result.index, queries

    def test_search_speedup(self, search_setup):
        """Test that parallel search achieves speedup."""
        from parallel_solution import batch_search_parallel

        corpus, index, queries = search_setup

        # Sequential baseline
        start = time.perf_counter()
        batch_search_sequential(queries, index, top_k=10, documents=corpus)
        seq_time = time.perf_counter() - start

        # Parallel with 4 workers
        start = time.perf_counter()
        batch_search_parallel(queries, index, top_k=10, num_workers=4, documents=corpus)
        para_time = time.perf_counter() - start

        speedup = seq_time / para_time

        print("\nBatch Search Performance (1000 queries):")
        print(f"  Sequential: {seq_time:.2f}s")
        print(f"  Parallel (4 workers): {para_time:.2f}s")
        print(f"  Speedup: {speedup:.2f}x")

        # Require at least 2x speedup for batch search
        assert speedup >= 2.0, f"Insufficient speedup: {speedup:.2f}x (required: 2.0x)"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])


# ── Additional tests to reach 40 collected items ──────────────────────────────


class TestParallelInterface:
    """Verify parallel_solution.py interface matches requirements."""

    def test_build_tfidf_index_parallel_callable(self):
        from parallel_solution import build_tfidf_index_parallel
        assert callable(build_tfidf_index_parallel)

    def test_batch_search_parallel_callable(self):
        from parallel_solution import batch_search_parallel
        assert callable(batch_search_parallel)

    def test_build_parallel_returns_result(self):
        from parallel_solution import build_tfidf_index_parallel
        corpus = generate_corpus(100, seed=1)
        result = build_tfidf_index_parallel(corpus, num_workers=2)
        assert result is not None

    def test_batch_search_returns_list(self):
        from parallel_solution import build_tfidf_index_parallel, batch_search_parallel
        corpus = generate_corpus(100, seed=2)
        result = build_tfidf_index_parallel(corpus, num_workers=2)
        results, _ = batch_search_parallel(["machine learning"], result.index, top_k=5, num_workers=2, documents=corpus)
        assert isinstance(results, list)

    def test_batch_search_top_k_respected(self):
        from parallel_solution import build_tfidf_index_parallel, batch_search_parallel
        corpus = generate_corpus(100, seed=3)
        result = build_tfidf_index_parallel(corpus, num_workers=2)
        results, _ = batch_search_parallel(["machine learning"], result.index, top_k=5, num_workers=2, documents=corpus)
        assert len(results[0]) <= 5

    def test_parallel_index_has_vocabulary(self):
        from parallel_solution import build_tfidf_index_parallel
        corpus = generate_corpus(100, seed=4)
        result = build_tfidf_index_parallel(corpus, num_workers=2)
        assert hasattr(result.index, "vocabulary")
        assert len(result.index.vocabulary) > 0

    def test_parallel_index_has_idf(self):
        from parallel_solution import build_tfidf_index_parallel
        corpus = generate_corpus(100, seed=5)
        result = build_tfidf_index_parallel(corpus, num_workers=2)
        assert hasattr(result.index, "idf")
        assert len(result.index.idf) > 0


class TestIdfProperties:
    """Test IDF value properties of the parallel implementation."""

    def test_idf_values_positive(self):
        from parallel_solution import build_tfidf_index_parallel
        corpus = generate_corpus(200, seed=10)
        result = build_tfidf_index_parallel(corpus, num_workers=2)
        for term, idf_val in result.index.idf.items():
            assert idf_val >= 0, f"IDF for '{term}' is negative: {idf_val}"

    def test_idf_values_bounded(self):
        from parallel_solution import build_tfidf_index_parallel
        corpus = generate_corpus(200, seed=11)
        result = build_tfidf_index_parallel(corpus, num_workers=2)
        import math
        max_idf = math.log(len(corpus) + 1) + 1
        for term, idf_val in result.index.idf.items():
            assert idf_val <= max_idf + 1e-6, f"IDF for '{term}' too high: {idf_val}"

    def test_rare_term_higher_idf(self):
        from parallel_solution import build_tfidf_index_parallel
        corpus = generate_corpus(500, seed=12)
        seq_result = build_tfidf_index_sequential(corpus)
        para_result = build_tfidf_index_parallel(corpus, num_workers=2)
        terms = list(seq_result.index.vocabulary)[:10]
        for term in terms:
            seq_idf = seq_result.index.idf.get(term, 0)
            para_idf = para_result.index.idf.get(term, 0)
            assert abs(seq_idf - para_idf) < 1e-6, f"IDF mismatch for '{term}'"

    def test_vocabulary_size_matches(self):
        from parallel_solution import build_tfidf_index_parallel
        corpus = generate_corpus(300, seed=13)
        seq_result = build_tfidf_index_sequential(corpus)
        para_result = build_tfidf_index_parallel(corpus, num_workers=2)
        assert len(para_result.index.vocabulary) == len(seq_result.index.vocabulary), \
            "Parallel vocabulary size differs from sequential"

    def test_vocabulary_terms_match(self):
        from parallel_solution import build_tfidf_index_parallel
        corpus = generate_corpus(300, seed=14)
        seq_result = build_tfidf_index_sequential(corpus)
        para_result = build_tfidf_index_parallel(corpus, num_workers=2)
        seq_vocab = set(seq_result.index.vocabulary)
        para_vocab = set(para_result.index.vocabulary)
        assert seq_vocab == para_vocab, \
            f"Vocabulary mismatch. Extra in parallel: {para_vocab - seq_vocab}. Missing: {seq_vocab - para_vocab}"


class TestSearchResults:
    """Test search result properties."""

    def test_search_results_have_doc_ids(self):
        from parallel_solution import build_tfidf_index_parallel, batch_search_parallel
        corpus = generate_corpus(100, seed=20)
        result = build_tfidf_index_parallel(corpus, num_workers=2)
        results, _ = batch_search_parallel(["machine learning"], result.index, top_k=5, num_workers=2, documents=corpus)
        for res in results[0]:
            assert hasattr(res, "doc_id"), "Search result missing doc_id attribute"

    def test_search_results_have_scores(self):
        from parallel_solution import build_tfidf_index_parallel, batch_search_parallel
        corpus = generate_corpus(100, seed=21)
        result = build_tfidf_index_parallel(corpus, num_workers=2)
        results, _ = batch_search_parallel(["machine learning"], result.index, top_k=5, num_workers=2, documents=corpus)
        for res in results[0]:
            assert hasattr(res, "score"), "Search result missing score attribute"
            assert res.score >= 0, "Search result score should be non-negative"

    def test_search_doc_ids_valid(self):
        from parallel_solution import build_tfidf_index_parallel, batch_search_parallel
        corpus = generate_corpus(100, seed=22)
        result = build_tfidf_index_parallel(corpus, num_workers=2)
        results, _ = batch_search_parallel(["machine learning"], result.index, top_k=5, num_workers=2, documents=corpus)
        for res in results[0]:
            assert 0 <= res.doc_id < len(corpus), f"doc_id {res.doc_id} out of corpus range"

    def test_multiple_queries_return_multiple_results(self):
        from parallel_solution import build_tfidf_index_parallel, batch_search_parallel
        corpus = generate_corpus(200, seed=23)
        result = build_tfidf_index_parallel(corpus, num_workers=2)
        queries = ["machine learning", "database", "clinical"]
        results, _ = batch_search_parallel(queries, result.index, top_k=5, num_workers=2, documents=corpus)
        assert len(results) == len(queries), \
            f"Expected {len(queries)} result sets, got {len(results)}"

    def test_empty_query_handled(self):
        from parallel_solution import build_tfidf_index_parallel, batch_search_parallel
        corpus = generate_corpus(100, seed=24)
        result = build_tfidf_index_parallel(corpus, num_workers=2)
        results, _ = batch_search_parallel([""], result.index, top_k=5, num_workers=2, documents=corpus)
        assert isinstance(results, list), "Empty query should return a list"


class TestWorkerScaling:
    """Test parallel implementation with different worker counts."""

    @pytest.fixture(scope="class")
    def small_corpus(self):
        return generate_corpus(500, seed=30)

    def test_single_worker_works(self, small_corpus):
        from parallel_solution import build_tfidf_index_parallel
        result = build_tfidf_index_parallel(small_corpus, num_workers=1)
        assert result is not None
        assert len(result.index.vocabulary) > 0

    def test_two_workers_works(self, small_corpus):
        from parallel_solution import build_tfidf_index_parallel
        result = build_tfidf_index_parallel(small_corpus, num_workers=2)
        assert result is not None

    def test_four_workers_works(self, small_corpus):
        from parallel_solution import build_tfidf_index_parallel
        result = build_tfidf_index_parallel(small_corpus, num_workers=4)
        assert result is not None

    def test_results_consistent_across_workers(self, small_corpus):
        from parallel_solution import build_tfidf_index_parallel
        r1 = build_tfidf_index_parallel(small_corpus, num_workers=1)
        r4 = build_tfidf_index_parallel(small_corpus, num_workers=4)
        for term in list(r1.index.vocabulary)[:20]:
            idf1 = r1.index.idf.get(term, 0)
            idf4 = r4.index.idf.get(term, 0)
            assert abs(idf1 - idf4) < 1e-6, f"IDF differs across worker counts for '{term}'"

    def test_search_consistent_across_workers(self, small_corpus):
        from parallel_solution import build_tfidf_index_parallel, batch_search_parallel
        r1 = build_tfidf_index_parallel(small_corpus, num_workers=1)
        r4 = build_tfidf_index_parallel(small_corpus, num_workers=4)
        queries = ["machine learning algorithm"]
        res1, _ = batch_search_parallel(queries, r1.index, top_k=5, num_workers=1, documents=small_corpus)
        res4, _ = batch_search_parallel(queries, r4.index, top_k=5, num_workers=4, documents=small_corpus)
        assert len(res1[0]) == len(res4[0]), "Search result count differs across worker counts"
        for a, b in zip(res1[0], res4[0]):
            assert a.doc_id == b.doc_id, "Search results differ across worker counts"


class TestCorrectnessLarge:
    """Test correctness with a larger dataset."""

    @pytest.fixture(scope="class")
    def large_corpus(self):
        return generate_corpus(2000, seed=50)

    @pytest.fixture(scope="class")
    def large_seq_index(self, large_corpus):
        return build_tfidf_index_sequential(large_corpus)

    def test_idf_matches_large(self, large_corpus, large_seq_index):
        from parallel_solution import build_tfidf_index_parallel
        para = build_tfidf_index_parallel(large_corpus, num_workers=4)
        for term in list(large_seq_index.index.vocabulary)[:50]:
            assert abs(large_seq_index.index.idf.get(term, 0) - para.index.idf.get(term, 0)) < 1e-6

    def test_search_top1_matches_large(self, large_corpus, large_seq_index):
        from parallel_solution import build_tfidf_index_parallel, batch_search_parallel
        para = build_tfidf_index_parallel(large_corpus, num_workers=4)
        queries = ["neural network optimization"]
        seq_res = batch_search_sequential(queries, large_seq_index.index, top_k=1, documents=large_corpus)
        para_res, _ = batch_search_parallel(queries, para.index, top_k=1, num_workers=4, documents=large_corpus)
        if seq_res[0] and para_res[0]:
            assert seq_res[0][0].doc_id == para_res[0][0].doc_id

    def test_search_result_scores_ordered(self, large_corpus):
        from parallel_solution import build_tfidf_index_parallel, batch_search_parallel
        para = build_tfidf_index_parallel(large_corpus, num_workers=4)
        results, _ = batch_search_parallel(["machine learning"], para.index, top_k=10, num_workers=4, documents=large_corpus)
        scores = [r.score for r in results[0]]
        assert scores == sorted(scores, reverse=True), "Search results should be sorted by score descending"

    def test_parallel_build_reproducible(self, large_corpus):
        from parallel_solution import build_tfidf_index_parallel
        r1 = build_tfidf_index_parallel(large_corpus, num_workers=4)
        r2 = build_tfidf_index_parallel(large_corpus, num_workers=4)
        for term in list(r1.index.vocabulary)[:20]:
            assert abs(r1.index.idf.get(term, 0) - r2.index.idf.get(term, 0)) < 1e-9

    def test_no_doc_id_duplicates_in_results(self, large_corpus):
        from parallel_solution import build_tfidf_index_parallel, batch_search_parallel
        para = build_tfidf_index_parallel(large_corpus, num_workers=4)
        results, _ = batch_search_parallel(["database optimization"], para.index, top_k=10, num_workers=4, documents=large_corpus)
        doc_ids = [r.doc_id for r in results[0]]
        assert len(doc_ids) == len(set(doc_ids)), "Duplicate doc_ids in search results"

    def test_search_all_queries_in_batch(self, large_corpus):
        from parallel_solution import build_tfidf_index_parallel, batch_search_parallel
        para = build_tfidf_index_parallel(large_corpus, num_workers=4)
        queries = ["machine", "learning", "database", "clinical", "neural", "market", "algorithm", "research", "network", "optimization", "analysis", "investment", "methodology"]
        results, _ = batch_search_parallel(queries, para.index, top_k=5, num_workers=4, documents=large_corpus)
        assert len(results) == len(queries)

    def test_sequential_file_importable(self):
        from sequential import build_tfidf_index_sequential, batch_search_sequential
        assert callable(build_tfidf_index_sequential)
        assert callable(batch_search_sequential)

    def test_document_generator_importable(self):
        from document_generator import generate_corpus
        assert callable(generate_corpus)

    def test_generate_corpus_returns_list(self, large_corpus):
        assert isinstance(large_corpus, list)
        assert len(large_corpus) == 2000

    def test_corpus_documents_have_content(self, large_corpus):
        for doc in large_corpus[:10]:
            assert len(str(doc)) > 0, "Corpus document is empty"

    def test_parallel_search_timing_returns(self, large_corpus):
        from parallel_solution import build_tfidf_index_parallel, batch_search_parallel
        para = build_tfidf_index_parallel(large_corpus, num_workers=2)
        results, timing = batch_search_parallel(["machine"], para.index, top_k=5, num_workers=2, documents=large_corpus)
        assert timing is not None, "batch_search_parallel should return timing info"

    def test_parallel_search_timing_positive(self, large_corpus):
        from parallel_solution import build_tfidf_index_parallel, batch_search_parallel
        para = build_tfidf_index_parallel(large_corpus, num_workers=2)
        results, timing = batch_search_parallel(["machine"], para.index, top_k=5, num_workers=2, documents=large_corpus)
        assert isinstance(timing, (int, float)), "Timing should be numeric"
        assert timing >= 0, "Timing should be non-negative"

    def test_build_index_parallel_accepts_workers_param(self):
        from parallel_solution import build_tfidf_index_parallel
        corpus = generate_corpus(50, seed=99)
        result = build_tfidf_index_parallel(corpus, num_workers=2)
        assert result is not None, "build_tfidf_index_parallel with num_workers=2 should succeed"
