#!/usr/bin/env python3
from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path

import pytest

TEST_SCALA_FILE = Path("Tokenizer.scala")
TEST_BUILD_FILE = Path("build.sbt")
TEST_SPEC_FILE = Path("TokenizerSpec.scala")
TEST_PROJECT_DIR = Path("localtest")
PROJECT_MAIN_DIR = TEST_PROJECT_DIR / "src" / "main" / "scala" / "tokenizer"
PROJECT_TEST_DIR = TEST_PROJECT_DIR / "src" / "test" / "scala" / "tokenizer"
PROBE_FILE = PROJECT_MAIN_DIR / "HoldoutProbe.scala"

REQUIRED_COMPONENT_PATTERNS = (
    ("TokenType", r"(sealed\s+trait|enum)\s+TokenType"),
    ("Token", r"(case\s+class|class)\s+Token"),
    ("TokenContainer", r"(case\s+class|class)\s+TokenContainer"),
    ("BaseTokenizer", r"(abstract\s+class|trait)\s+BaseTokenizer"),
    ("StringTokenizer", r"class\s+StringTokenizer"),
    ("NumericTokenizer", r"class\s+NumericTokenizer"),
    ("TemporalTokenizer", r"class\s+TemporalTokenizer"),
    ("UniversalTokenizer", r"class\s+UniversalTokenizer"),
    ("WhitespaceTokenizer", r"class\s+WhitespaceTokenizer"),
    ("JsonTokenizer", r"class\s+JsonTokenizer"),
    ("TokenRegistry", r"class\s+TokenRegistry"),
    ("TokenizerBuilder", r"class\s+TokenizerBuilder"),
)

REQUIRED_METHOD_PATTERNS = (
    ("tokenize", r"def\s+tokenize\s*[\(\[]"),
    ("tokenizeBatch", r"def\s+tokenizeBatch\s*[\(\[]"),
    ("withMetadata", r"def\s+withMetadata\s*[\(\[]"),
    ("register", r"def\s+register\s*[\(\[]"),
    ("process", r"def\s+process\s*[\(\[]"),
    ("map", r"def\s+map\s*[\(\[]"),
    ("flatMap", r"def\s+flatMap\s*[\(\[]"),
    ("build", r"def\s+build\s*[\(\[]"),
)

FORBIDDEN_SOURCE_PATTERNS = (
    "pass  # type: ignore",
    "TODO(",
    "NotImplementedError",
    "???",
    "null.asInstanceOf",
    "throw new UnsupportedOperationException",
)

PROBE_SOURCE = """package tokenizer

import java.time.LocalDate

object HoldoutProbe {
  private def emit(k: String, v: Any): Unit = println(s"H|$k|${Option(v).map(_.toString).getOrElse("null")}")

  def main(args: Array[String]): Unit = {
    val token = Token("hello", TokenType.STRING).withMetadata("k" -> "v")
    emit("token_type", token.tokenType.value)
    emit("token_meta", token.metadata.getOrElse("k", ""))

    val container = new TokenContainer(Seq("a", "b"))
    emit("container_size", container.size)

    val normalized = new StringTokenizer(normalizer = _.trim.toLowerCase).tokenize("  A  ")
    emit("normalized", normalized.value)

    val numeric = new NumericTokenizer(precision = 2).tokenize(3.14159)
    emit("numeric_type", numeric.tokenType.value)

    val temporal = new TemporalTokenizer().tokenize(LocalDate.of(2024, 1, 1))
    emit("temporal_type", temporal.tokenType.value)

    val universal = new UniversalTokenizer()
    emit("universal_null_type", universal.tokenizeNull.tokenType.value)

    val ws = new WhitespaceTokenizer(lowercase = true).tokenize("One Two")
    emit("ws_count", ws.size)

    val registry = new TokenRegistry[String]
    registry.register("d", new TokenContainer(Seq("x", "y")))
    registry.addHandler(v => Some(Token(v.toUpperCase, TokenType.STRING)))
    emit("registry_non_empty", registry.process("d").flatten.nonEmpty)

    val builder = TokenizerBuilder[String]().withNormalizer(_.trim).withMetadata("m" -> "1").build()
    val built = builder(" z ")
    emit("builder_value", built.value)
    emit("builder_meta", built.metadata.getOrElse("m", ""))
  }
}
"""


def _run(command: list[str], cwd: Path, timeout: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, cwd=cwd, capture_output=True, text=True, timeout=timeout, check=False)


def _prepare_project() -> None:
    if TEST_PROJECT_DIR.exists():
        shutil.rmtree(TEST_PROJECT_DIR)
    PROJECT_MAIN_DIR.mkdir(parents=True, exist_ok=True)
    PROJECT_TEST_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy(TEST_SCALA_FILE, PROJECT_MAIN_DIR / "Tokenizer.scala")
    shutil.copy(TEST_BUILD_FILE, TEST_PROJECT_DIR / "build.sbt")
    shutil.copy(TEST_SPEC_FILE, PROJECT_TEST_DIR / "TokenizerSpec.scala")
    PROBE_FILE.write_text(PROBE_SOURCE, encoding="utf-8")


@pytest.fixture(scope="session")
def source_text() -> str:
    assert TEST_SCALA_FILE.exists()
    return TEST_SCALA_FILE.read_text(encoding="utf-8")


@pytest.fixture(scope="session")
def compile_result() -> subprocess.CompletedProcess[str]:
    assert shutil.which("sbt"), "sbt is not available"
    _prepare_project()
    return _run(["sbt", "compile"], cwd=TEST_PROJECT_DIR, timeout=360)


@pytest.fixture(scope="session")
def sbt_test_result(compile_result: subprocess.CompletedProcess[str]) -> subprocess.CompletedProcess[str]:
    if compile_result.returncode != 0:
        return subprocess.CompletedProcess(args=["sbt", "test"], returncode=1, stdout="", stderr=compile_result.stdout + compile_result.stderr)
    return _run(["sbt", "test"], cwd=TEST_PROJECT_DIR, timeout=600)


@pytest.fixture(scope="session")
def probe_results(compile_result: subprocess.CompletedProcess[str]) -> dict[str, str]:
    if compile_result.returncode != 0:
        return {}
    probe = _run(["sbt", "runMain", "tokenizer.HoldoutProbe"], cwd=TEST_PROJECT_DIR, timeout=360)
    text = (probe.stdout or "") + (probe.stderr or "")
    if probe.returncode != 0:
        return {}
    result: dict[str, str] = {}
    for line in text.splitlines():
        if not line.startswith("H|"):
            continue
        _, key, value = line.split("|", 2)
        result[key] = value
    return result


def _sbt_total_tests(text: str) -> int:
    match = re.search(r"(\d+)\s+tests?\s+were", text, re.IGNORECASE)
    if match:
        return int(match.group(1))
    passed = re.search(r"(\d+)\s+tests?\s+succeeded", text, re.IGNORECASE)
    failed = re.search(r"(\d+)\s+tests?\s+failed", text, re.IGNORECASE)
    return int(passed.group(1) if passed else 0) + int(failed.group(1) if failed else 0)


def test_holdout_compiles(compile_result: subprocess.CompletedProcess[str]) -> None:
    assert compile_result.returncode == 0, (compile_result.stdout or "") + (compile_result.stderr or "")


def test_holdout_sbt_tests_pass(sbt_test_result: subprocess.CompletedProcess[str]) -> None:
    assert sbt_test_result.returncode == 0, (sbt_test_result.stdout or "") + (sbt_test_result.stderr or "")


def test_holdout_sbt_test_count(sbt_test_result: subprocess.CompletedProcess[str]) -> None:
    total = _sbt_total_tests((sbt_test_result.stdout or "") + (sbt_test_result.stderr or ""))
    assert total >= 10


@pytest.mark.parametrize("name,pattern", REQUIRED_COMPONENT_PATTERNS)
def test_holdout_required_components(source_text: str, name: str, pattern: str) -> None:
    assert re.search(pattern, source_text), f"missing component {name}"


@pytest.mark.parametrize("name,pattern", REQUIRED_METHOD_PATTERNS)
def test_holdout_required_methods(source_text: str, name: str, pattern: str) -> None:
    assert re.search(pattern, source_text), f"missing method {name}"


@pytest.mark.parametrize("forbidden", FORBIDDEN_SOURCE_PATTERNS)
def test_holdout_forbidden_placeholders_absent(source_text: str, forbidden: str) -> None:
    assert forbidden not in source_text


@pytest.mark.parametrize(
    "key,expected",
    (
        ("token_type", "string"),
        ("token_meta", "v"),
        ("container_size", "2"),
        ("normalized", "a"),
        ("numeric_type", "numeric"),
        ("temporal_type", "temporal"),
        ("universal_null_type", "string"),
        ("ws_count", "2"),
        ("registry_non_empty", "true"),
        ("builder_value", "z"),
        ("builder_meta", "1"),
    ),
)
def test_holdout_runtime_probe_expectations(
    probe_results: dict[str, str],
    key: str,
    expected: str,
) -> None:
    assert probe_results.get(key) == expected, f"{key}={probe_results.get(key)!r}"
