from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

import pytest

WORKSPACE_DIR = Path("/workspace")
POM_PATH = WORKSPACE_DIR / "pom.xml"
SECURITY_CONFIG = WORKSPACE_DIR / "src/main/java/com/example/userservice/config/SecurityConfig.java"
USER_JAVA = WORKSPACE_DIR / "src/main/java/com/example/userservice/model/User.java"
REQUEST_JAVA = WORKSPACE_DIR / "src/main/java/com/example/userservice/dto/CreateUserRequest.java"
EXTERNAL_SERVICE = WORKSPACE_DIR / "src/main/java/com/example/userservice/service/ExternalApiService.java"
CONTROLLER_JAVA = WORKSPACE_DIR / "src/main/java/com/example/userservice/controller/UserController.java"
USER_SERVICE = WORKSPACE_DIR / "src/main/java/com/example/userservice/service/UserService.java"
GLOBAL_HANDLER = WORKSPACE_DIR / "src/main/java/com/example/userservice/exception/GlobalExceptionHandler.java"
REPOSITORY_JAVA = WORKSPACE_DIR / "src/main/java/com/example/userservice/repository/UserRepository.java"
MAIN_JAVA_DIR = WORKSPACE_DIR / "src/main/java"


def _read(path: Path) -> str:
    assert path.exists(), f"{path.name} not found"
    return path.read_text(encoding="utf-8")


def _all_java_files() -> list[Path]:
    java_files: list[Path] = []
    for root, _dirs, files in os.walk(MAIN_JAVA_DIR):
        for file in files:
            if file.endswith(".java"):
                java_files.append(Path(root) / file)
    return sorted(java_files)


@pytest.fixture(scope="session")
def java_files() -> list[Path]:
    return _all_java_files()


@pytest.fixture(scope="session")
def compile_result() -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["bash", "-c", "source /root/.sdkman/bin/sdkman-init.sh && sdk use java 21.0.2-tem && mvn clean compile -q"],
        cwd=WORKSPACE_DIR,
        capture_output=True,
        text=True,
        timeout=300,
        check=False,
    )


@pytest.fixture(scope="session")
def test_result(compile_result: subprocess.CompletedProcess[str]) -> subprocess.CompletedProcess[str]:
    if compile_result.returncode != 0:
        return subprocess.CompletedProcess(args=["mvn", "test"], returncode=1, stdout="", stderr=compile_result.stdout + compile_result.stderr)
    return subprocess.run(
        ["bash", "-c", "source /root/.sdkman/bin/sdkman-init.sh && sdk use java 21.0.2-tem && mvn test -q"],
        cwd=WORKSPACE_DIR,
        capture_output=True,
        text=True,
        timeout=300,
        check=False,
    )


def test_holdout_compile_passes(compile_result: subprocess.CompletedProcess[str]) -> None:
    assert compile_result.returncode == 0, compile_result.stdout + compile_result.stderr


def test_holdout_maven_tests_pass(test_result: subprocess.CompletedProcess[str]) -> None:
    assert test_result.returncode == 0, test_result.stdout + test_result.stderr


def test_holdout_javax_removed_from_all_java_files(java_files: list[Path]) -> None:
    for java_file in java_files:
        content = _read(java_file)
        assert "javax.validation" not in content
        assert "javax.persistence" not in content
        assert "javax.servlet" not in content


@pytest.mark.parametrize(
    "path,marker",
    (
        (USER_JAVA, "jakarta.persistence"),
        (REQUEST_JAVA, "jakarta.validation"),
        (CONTROLLER_JAVA, "jakarta.validation.Valid"),
        (GLOBAL_HANDLER, "jakarta.servlet.http.HttpServletRequest"),
    ),
)
def test_holdout_required_jakarta_markers(path: Path, marker: str) -> None:
    assert marker in _read(path)


@pytest.mark.parametrize(
    "marker",
    (
        "EnableMethodSecurity",
        "requestMatchers",
        "authorizeHttpRequests",
        "SecurityFilterChain",
        "securityFilterChain",
        "AuthenticationManager",
        "http.build()",
        "csrf",
    ),
)
def test_holdout_security_markers_present(marker: str) -> None:
    assert marker in _read(SECURITY_CONFIG)


@pytest.mark.parametrize(
    "marker",
    (
        "RestClient",
        ".get()",
        ".post()",
        ".delete()",
        ".retrieve()",
        "MediaType.APPLICATION_JSON",
        "ParameterizedTypeReference",
        "\"/users/\" + userId + \"/profile\"",
    ),
)
def test_holdout_restclient_markers_present(marker: str) -> None:
    assert marker in _read(EXTERNAL_SERVICE)


@pytest.mark.parametrize(
    "marker",
    (
        "<artifactId>spring-boot-starter-parent</artifactId>",
        "<java.version>21</java.version>",
        "jjwt-api",
        "jjwt-impl",
        "jjwt-jackson",
        "<artifactId>spring-boot-starter-test</artifactId>",
        "<artifactId>spring-boot-starter-security</artifactId>",
    ),
)
def test_holdout_pom_dependency_markers_present(marker: str) -> None:
    assert marker in _read(POM_PATH)


@pytest.mark.parametrize(
    "marker",
    (
        "getAllUsers",
        "getUserById",
        "createUser",
        "updateUser",
        "deleteUser",
        "searchUsers",
    ),
)
def test_holdout_service_and_controller_methods_preserved(marker: str) -> None:
    merged = _read(USER_SERVICE) + "\n" + _read(CONTROLLER_JAVA)
    assert marker in merged


@pytest.mark.parametrize(
    "forbidden",
    (
        "WebSecurityConfigurerAdapter",
        "antMatchers",
        "<version>2.7.",
        "<java.version>1.8</java.version>",
    ),
)
def test_holdout_legacy_markers_absent(forbidden: str) -> None:
    merged = _read(POM_PATH) + "\n" + _read(SECURITY_CONFIG)
    assert forbidden not in merged
