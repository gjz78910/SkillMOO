#!/bin/bash

set -eo pipefail

mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt

set +u
source /root/.sdkman/bin/sdkman-init.sh
sdk use java 21.0.2-tem 2>/dev/null || true
set -eo pipefail

set +e
python3 -m pytest /tests/test_holdout_outputs.py -rA -v 2>&1 \
    | tee /logs/verifier/test-stdout.txt
set -e

reward_value="$(python3 - <<'PY'
import re
from pathlib import Path

stdout_path = Path("/logs/verifier/test-stdout.txt")
if not stdout_path.exists():
    print("")
    raise SystemExit(0)
try:
    text = stdout_path.read_text(encoding="utf-8", errors="ignore")
except Exception:
    print("")
    raise SystemExit(0)
summary_line = None
for raw_line in reversed(text.splitlines()):
    line = raw_line.strip()
    lowered = line.lower()
    if "=" in line and " in " in lowered and any(
        token in lowered for token in ("passed", "failed", "error", "errors", "skipped", "xfailed", "xpassed")
    ):
        summary_line = line
        break
if summary_line is None:
    print("")
    raise SystemExit(0)
counts = {key: 0 for key in ("passed", "failed", "error", "errors", "skipped", "xfailed", "xpassed")}
for match in re.finditer(
    r"(?P<count>\d+)\s+(?P<label>passed|failed|error|errors|skipped|xfailed|xpassed)\b",
    summary_line,
    flags=re.IGNORECASE,
):
    label = str(match.group("label") or "").strip().lower()
    if label in counts:
        counts[label] += int(match.group("count") or 0)
passed = counts["passed"] + counts["xpassed"]
failed = counts["failed"] + counts["error"] + counts["errors"]
skipped = counts["skipped"] + counts["xfailed"]
total = passed + failed + skipped
if total <= 0:
    print("")
    raise SystemExit(0)
print(f"{passed/total:.6f}")
PY
)"
if [ -n "$reward_value" ]; then
  printf "%s\n" "$reward_value" > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi

exit 0
