---
name: patch-diff-workflow
description: Follow a patch-first repair workflow for code-fix tasks that require writing patch_i.diff files, then applying and validating changes. Trigger when instructions explicitly require diff artifacts.
---

# Patch Diff Workflow

Use when the task requires explicit diff files before applying fixes.

## Required Sequence

1. Analyze and record failure reasons in a notes file.
2. Write proposed edits into `patch_{i}.diff` files (unified diff format).
3. Apply patch files to the target repository.
4. Verify build/tests after applying patches.

## Diff Rules

- Keep each patch focused on one coherent root cause.
- Preserve file paths expected by the repository.
- Avoid mixing unrelated changes into one patch.

## Verification Rules

1. Check patch file existence and parse validity.
2. Run required verifier/build command.
3. If still failing, append a new patch file and iterate.
