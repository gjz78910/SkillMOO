---
name: pyproject-tox-compat
description: Resolve Python packaging and test-runner compatibility issues across pyproject.toml, tox.ini, and dependency versions. Trigger when build failures involve install/import/config mismatches.
---

# pyproject + tox Compatibility

Use this when failures involve packaging, dependency resolution, or test environment setup.

## Checkpoints

1. Inspect `pyproject.toml` metadata and dependency declarations.
2. Inspect `tox.ini` test env commands and dependency constraints.
3. Verify import paths against installed package versions.
4. Confirm editable vs non-editable install expectations.
5. If `setuptools.build_meta` is used, assume `pip install -e .` may fail unless editable support is explicit.

## Typical Repairs

- Correct outdated import modules after dependency upgrades.
- Align dependency constraints with code expectations.
- Keep test command behavior consistent with project tooling.
- Minimize dependency churn; prefer compatibility fixes.

## Safety

1. Do not change unrelated package pins.
2. Re-test after each compatibility edit.
3. Avoid broad dependency installs before confirming the failing import or test actually needs them.
