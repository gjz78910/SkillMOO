---
name: python-build-fix-playbook
description: Fix failing Python builds and tests in existing repositories. Trigger when a task asks to analyze build failures, identify code/config root causes, and repair them with minimal edits.
---

# Python Build Fix Playbook

Use this workflow when the task is to repair a broken Python repository build.

## Fast Triage

1. Confirm project layout and build/test entrypoints.
2. Reproduce failure with the project's configured runner (`pytest`, `tox`, CI script).
3. Extract the first deterministic failure and stack trace.
4. Separate root cause from downstream failures.
5. Inspect `pyproject.toml` and `tox.ini` before attempting package installs.

## Fix Strategy

1. Prefer the smallest code/config change that resolves root cause.
2. Keep dependency/API compatibility in mind (`pyproject.toml`, `tox.ini`, import paths).
3. Re-run targeted failing checks first, then full verification.
4. Avoid broad refactors unless strictly required for the failing checks.

## Avoid Wasted Setup

1. Do not start with `pip install -e .` if the project uses `setuptools.build_meta` and may not support editable installs.
2. Do not install broad optional stacks such as `langchain` or `openai` unless the first failing traceback proves they are required.
3. Do not replace the project's runner with a custom one-shot install command before reading the actual test failure.

## Output Discipline

1. Record concise failure analysis before editing.
2. Produce patch files in standard unified diff format.
3. Apply patch files and re-run validation.
