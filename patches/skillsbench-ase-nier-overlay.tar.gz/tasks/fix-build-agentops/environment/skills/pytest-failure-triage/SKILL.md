---
name: pytest-failure-triage
description: Debug pytest failures quickly by isolating first failing tests, reading tracebacks, and validating targeted fixes. Trigger when tests fail during build verification.
---

# Pytest Failure Triage

Use this when CI/build failures are test-driven.

## Triage Loop

1. Run the narrowest failing test first (`-k`, specific file/test id).
2. Capture exact assertion or exception location.
3. Identify whether failure is from product code, test assumptions, or environment mismatch.
4. Fix one root cause at a time and re-run the same test.

## Common Failure Classes

- Import/module path breakage
- API/version drift
- Type and nullability errors
- Test fixture/setup mismatch
- Packaging/install-time errors that surface during tests

## Validation

1. Re-run affected tests.
2. Re-run full verifier command after local targeted checks pass.
