"""
Verifier tests for Spring Boot 2 -> 3 migration.

The goal is to keep the expensive compile/test checks at one run each while
expanding the migration checks so the verifier can separate partial, good,
and strong migrations across namespace updates, security migration, dependency
updates, REST client migration, and preserved application features.
"""

from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

import pytest

WORKSPACE_DIR = Path("/workspace")
POM_PATH = WORKSPACE_DIR / "pom.xml"
SECURITY_CONFIG = WORKSPACE_DIR / "src/main/java/com/example/userservice/config/SecurityConfig.java"
USER_JAVA = WORKSPACE_DIR / "src/main/java/com/example/userservice/model/User.java"
REQUEST_JAVA = WORKSPACE_DIR / "src/main/java/com/example/userservice/dto/CreateUserRequest.java"
EXTERNAL_SERVICE = WORKSPACE_DIR / "src/main/java/com/example/userservice/service/ExternalApiService.java"
CONTROLLER_JAVA = WORKSPACE_DIR / "src/main/java/com/example/userservice/controller/UserController.java"
USER_SERVICE = WORKSPACE_DIR / "src/main/java/com/example/userservice/service/UserService.java"
GLOBAL_HANDLER = WORKSPACE_DIR / "src/main/java/com/example/userservice/exception/GlobalExceptionHandler.java"
REPOSITORY_JAVA = WORKSPACE_DIR / "src/main/java/com/example/userservice/repository/UserRepository.java"
MAIN_JAVA_DIR = WORKSPACE_DIR / "src/main/java"


def _read(path: Path) -> str:
    assert path.exists(), f"{path.name} not found"
    return path.read_text(encoding="utf-8")


def _all_java_files() -> list[Path]:
    java_files: list[Path] = []
    for root, _dirs, files in os.walk(MAIN_JAVA_DIR):
        for file in files:
            if file.endswith(".java"):
                java_files.append(Path(root) / file)
    return sorted(java_files)


def _assert_markers_present(content: str, markers: tuple[str, ...], context: str) -> None:
    for marker in markers:
        assert marker in content, f"{context} is missing marker {marker}"


@pytest.fixture(scope="session")
def java_files() -> list[Path]:
    return _all_java_files()


@pytest.fixture(scope="session")
def compile_result():
    result = subprocess.run(
        ["bash", "-c", "source /root/.sdkman/bin/sdkman-init.sh && sdk use java 21.0.2-tem && mvn clean compile -q"],
        cwd=WORKSPACE_DIR,
        capture_output=True,
        text=True,
        timeout=300,
    )
    return result


@pytest.fixture(scope="session")
def test_result(compile_result):
    if compile_result.returncode != 0:
        pytest.skip("Compile failed; Maven test diagnostics unavailable")
    result = subprocess.run(
        ["bash", "-c", "source /root/.sdkman/bin/sdkman-init.sh && sdk use java 21.0.2-tem && mvn test -q"],
        cwd=WORKSPACE_DIR,
        capture_output=True,
        text=True,
        timeout=300,
    )
    return result


class TestProjectWideNamespaceMigration:
    def test_no_javax_validation_anywhere(self, java_files: list[Path]):
        for java_file in java_files:
            assert "javax.validation" not in _read(java_file), f"Found javax.validation in {java_file}"

    def test_no_javax_persistence_anywhere(self, java_files: list[Path]):
        for java_file in java_files:
            assert "javax.persistence" not in _read(java_file), f"Found javax.persistence in {java_file}"

    def test_no_javax_servlet_anywhere(self, java_files: list[Path]):
        for java_file in java_files:
            assert "javax.servlet" not in _read(java_file), f"Found javax.servlet in {java_file}"

    def test_user_entity_uses_jakarta_persistence(self):
        assert "jakarta.persistence" in _read(USER_JAVA), "User.java should use jakarta.persistence"

    def test_request_uses_jakarta_validation(self):
        assert "jakarta.validation" in _read(REQUEST_JAVA), "CreateUserRequest.java should use jakarta.validation"

    def test_controller_uses_jakarta_valid(self):
        assert "jakarta.validation.Valid" in _read(CONTROLLER_JAVA), "UserController should use jakarta.validation.Valid"

    def test_user_service_uses_jakarta_entity_not_found(self):
        assert "jakarta.persistence.EntityNotFoundException" in _read(USER_SERVICE), (
            "UserService should use jakarta.persistence.EntityNotFoundException"
        )

    def test_exception_handler_uses_jakarta_persistence(self):
        assert "jakarta.persistence.EntityNotFoundException" in _read(GLOBAL_HANDLER), (
            "GlobalExceptionHandler should use jakarta.persistence.EntityNotFoundException"
        )

    def test_exception_handler_uses_jakarta_servlet_request(self):
        assert "jakarta.servlet.http.HttpServletRequest" in _read(GLOBAL_HANDLER), (
            "GlobalExceptionHandler should use jakarta.servlet.http.HttpServletRequest"
        )


class TestFeaturePreservation:
    def test_user_entity_annotations_survive_migration(self):
        _assert_markers_present(
            _read(USER_JAVA),
            ("@Entity", "@Table", "@Id", "@GeneratedValue", "@PrePersist", "@PreUpdate"),
            "User.java",
        )

    def test_request_validation_annotations_survive_migration(self):
        _assert_markers_present(
            _read(REQUEST_JAVA),
            ("@NotBlank", "@Email", "@Size"),
            "CreateUserRequest.java",
        )

    def test_controller_core_endpoint_annotations_survive(self):
        _assert_markers_present(
            _read(CONTROLLER_JAVA),
            (
                "@GetMapping",
                "@PostMapping",
                "@PutMapping",
                "@DeleteMapping",
                "@PatchMapping",
            ),
            "UserController.java",
        )

    def test_repository_core_query_methods_survive(self):
        _assert_markers_present(
            _read(REPOSITORY_JAVA),
            (
                "findByUsername",
                "findByEmail",
                "existsByUsername",
                "existsByEmail",
                "findByRole",
                "findByActiveTrue",
                "searchUsers",
            ),
            "UserRepository.java",
        )

    def test_repository_custom_query_annotations_survive(self):
        content = _read(REPOSITORY_JAVA)
        assert content.count("@Query") >= 2, "UserRepository should keep its custom query methods"

    def test_user_service_crud_methods_survive(self):
        _assert_markers_present(
            _read(USER_SERVICE),
            (
                "getAllUsers",
                "getUserById",
                "getUserByUsername",
                "createUser",
                "updateUser",
                "deleteUser",
                "deactivateUser",
                "searchUsers",
            ),
            "UserService.java",
        )


class TestSpringSecurityMigration:
    def test_enable_method_security(self):
        content = _read(SECURITY_CONFIG)
        assert "EnableGlobalMethodSecurity" not in content
        assert "EnableMethodSecurity" in content

    def test_request_matchers_used(self):
        content = _read(SECURITY_CONFIG)
        assert "antMatchers" not in content
        assert "requestMatchers" in content

    def test_web_security_configurer_adapter_removed(self):
        assert "WebSecurityConfigurerAdapter" not in _read(SECURITY_CONFIG)

    def test_authorize_http_requests_used(self):
        assert "authorizeHttpRequests" in _read(SECURITY_CONFIG)

    def test_security_filter_chain_present(self):
        content = _read(SECURITY_CONFIG)
        assert "SecurityFilterChain" in content
        assert "securityFilterChain" in content

    def test_component_based_auth_manager_present(self):
        content = _read(SECURITY_CONFIG)
        assert "AuthenticationConfiguration" in content or "AuthenticationManager" in content

    def test_security_config_uses_jakarta_servlet(self):
        content = _read(SECURITY_CONFIG)
        assert "jakarta.servlet" in content

    def test_security_config_builds_http_chain(self):
        assert "return http.build()" in _read(SECURITY_CONFIG)


class TestRestClientMigration:
    def test_rest_client_used(self):
        assert "RestClient" in _read(EXTERNAL_SERVICE)

    def test_external_service_keeps_all_operations(self):
        content = _read(EXTERNAL_SERVICE)
        for method_name in ("verifyEmail", "sendNotification", "enrichUserProfile", "requestDataDeletion"):
            assert method_name in content, f"ExternalApiService lost method {method_name}"

    def test_verify_email_uses_get_and_retrieve(self):
        content = _read(EXTERNAL_SERVICE)
        assert ".get()" in content and ".retrieve()" in content

    def test_send_notification_uses_post_and_body(self):
        content = _read(EXTERNAL_SERVICE)
        assert ".post()" in content and ".body(" in content

    def test_send_notification_uses_json_content_type(self):
        content = _read(EXTERNAL_SERVICE)
        assert "MediaType.APPLICATION_JSON" in content

    def test_enrich_user_profile_uses_parameterized_type_reference(self):
        assert "ParameterizedTypeReference" in _read(EXTERNAL_SERVICE)

    def test_enrich_user_profile_uses_generic_parameterized_type_reference(self):
        content = _read(EXTERNAL_SERVICE)
        assert re.search(r"ParameterizedTypeReference\s*<", content), (
            "ExternalApiService should use a generic ParameterizedTypeReference"
        )

    def test_enrich_user_profile_uses_typed_retrieve_body_call(self):
        content = _read(EXTERNAL_SERVICE)
        assert "ParameterizedTypeReference" in content and ".body(" in content, (
            "ExternalApiService should extract the profile response through a typed body(...) call"
        )

    def test_enrich_user_profile_keeps_profile_endpoint_shape(self):
        content = _read(EXTERNAL_SERVICE)
        assert '"/users/" + userId + "/profile"' in content, (
            "ExternalApiService should keep the profile endpoint path while migrating the client"
        )

    def test_request_data_deletion_uses_delete(self):
        assert ".delete()" in _read(EXTERNAL_SERVICE)


class TestDependencyUpdates:
    def test_spring_boot_parent_upgraded_to_3_2_x(self):
        content = _read(POM_PATH)
        assert "<version>2.7." not in content
        assert re.search(
            r"<parent>[\s\S]*?<artifactId>spring-boot-starter-parent</artifactId>[\s\S]*?<version>3\.2\.\d+</version>",
            content,
        ), "Spring Boot parent should be upgraded to 3.2.x"

    def test_java_version_upgraded_to_21(self):
        content = _read(POM_PATH)
        assert "<java.version>1.8</java.version>" not in content
        assert "<java.version>21</java.version>" in content, "Java version should be upgraded to 21"

    def test_no_old_jaxb_api(self):
        assert "javax.xml.bind" not in _read(POM_PATH)

    def test_no_legacy_jjwt_artifact(self):
        assert "<artifactId>jjwt</artifactId>" not in _read(POM_PATH)

    def test_modular_jjwt_dependencies_present(self):
        content = _read(POM_PATH)
        for artifact_id in ("jjwt-api", "jjwt-impl", "jjwt-jackson"):
            assert artifact_id in content, f"{artifact_id} should be present in pom.xml"


class TestBuildAndCompile:
    def test_maven_compile(self, compile_result):
        assert compile_result.returncode == 0, (
            f"Maven compile failed: {compile_result.stdout}\n{compile_result.stderr}"
        )

    def test_maven_test(self, test_result):
        assert test_result.returncode == 0, f"Maven test failed: {test_result.stdout}\n{test_result.stderr}"
