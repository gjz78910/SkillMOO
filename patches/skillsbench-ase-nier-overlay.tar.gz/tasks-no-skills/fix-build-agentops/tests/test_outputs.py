# pyright: reportMissingImports=false
"""
Verifier tests for the AgentOps build-fix task.

The key change here is density: we still run the expensive BugSwarm "passed"
workflow only once, but then expose many assertions from that single run so
the optimizer gets a finer-grained signal than 3 coarse checks.
"""

from __future__ import annotations

import importlib
import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

import pytest  # pyright: ignore[reportMissingImports]

GITHUB_ACTIONS_BUILD_PATH = Path("/home/github/build")
EXPECTED_ENVS = ("py310", "py311")
EXPECTED_TEST_FILES = (
    "tests/test_canary.py",
    "tests/test_events.py",
    "tests/test_record_function.py",
    "tests/test_session.py",
    "tests/test_teardown.py",
)
RUN_PASSED_TIMEOUT_SEC = 420
ENV_RUN_RE = re.compile(r"^(py\d+): commands\[0\]>", re.MULTILINE)
ENV_SUMMARY_RE = re.compile(r"^\s*(py\d+): (OK|FAIL|SKIP)\b", re.MULTILINE)
COLLECTED_RE = re.compile(r"collected\s+(\d+)\s+items")
TEST_FILE_RE = re.compile(r"^(tests/test_[^ ]+\.py)\s+([.FEsx]+)\s+\[\s*\d+%\]$")
EVENT_FILE = Path("agentops/event.py")
CLIENT_FILE = Path("agentops/client.py")
DISALLOWED_PATCH_TARGET_PREFIXES = ("tests/", "docs/")
DISALLOWED_PATCH_TARGETS = {"README.md", "logo.png"}


@dataclass
class BuildArtifacts:
    returncode: int
    stdout: str
    collected_items: dict[str, int] = field(default_factory=dict)
    env_statuses: dict[str, str] = field(default_factory=dict)
    file_statuses: dict[str, dict[str, str]] = field(default_factory=dict)


def _copy_failed_to_passed() -> None:
    failed_dir = GITHUB_ACTIONS_BUILD_PATH / "failed"
    passed_dir = GITHUB_ACTIONS_BUILD_PATH / "passed"
    assert failed_dir.exists(), "failed/ directory does not exist"
    assert any(failed_dir.iterdir()), "failed/ directory is not empty"
    if passed_dir.exists():
        shutil.rmtree(passed_dir)
    shutil.copytree(failed_dir, passed_dir)


def _parse_build_stdout(stdout: str) -> BuildArtifacts:
    artifacts = BuildArtifacts(returncode=-1, stdout=stdout)
    current_env: str | None = None
    for raw_line in stdout.splitlines():
        line = raw_line.rstrip()
        run_match = ENV_RUN_RE.match(line)
        if run_match:
            current_env = run_match.group(1)
            artifacts.file_statuses.setdefault(current_env, {})
            continue
        summary_match = ENV_SUMMARY_RE.match(line)
        if summary_match:
            artifacts.env_statuses[summary_match.group(1)] = summary_match.group(2)
            continue
        if current_env is None:
            continue
        collected_match = COLLECTED_RE.search(line)
        if collected_match:
            artifacts.collected_items[current_env] = int(collected_match.group(1))
            continue
        file_match = TEST_FILE_RE.match(line.strip())
        if file_match:
            path = file_match.group(1)
            symbols = file_match.group(2)
            artifacts.file_statuses.setdefault(current_env, {})[path] = (
                "pass" if set(symbols) <= {"."} else "fail"
            )
    return artifacts


@pytest.fixture(scope="session")
def build_artifacts() -> BuildArtifacts:
    _copy_failed_to_passed()
    try:
        result = subprocess.run(
            "bash run_passed.sh",
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            shell=True,
            cwd="/tests",
            text=True,
            timeout=RUN_PASSED_TIMEOUT_SEC,
        )
        stdout = result.stdout or ""
        returncode = result.returncode
    except subprocess.TimeoutExpired as exc:
        stdout = str(exc.stdout or "")
        stdout += (
            "\n[skillmoo verifier] run_passed.sh timed out after "
            f"{RUN_PASSED_TIMEOUT_SEC}s.\n"
        )
        returncode = 124
    except OSError as exc:
        stdout = f"[skillmoo verifier] run_passed.sh could not start: {exc}\n"
        returncode = 125
    artifacts = _parse_build_stdout(stdout)
    artifacts.returncode = returncode
    return artifacts


@pytest.fixture(scope="session")
def repo_root() -> Path:
    repo_id = os.getenv("REPO_ID")
    assert repo_id is not None, "REPO_ID environment variable is not set"
    root = GITHUB_ACTIONS_BUILD_PATH / "failed" / repo_id
    assert root.exists(), f"Repository root does not exist: {root}"
    return root


@pytest.fixture(scope="session")
def patch_files(repo_root: Path) -> list[Path]:
    diffs = [item for item in repo_root.iterdir() if item.is_file() and item.name.startswith("patch_") and item.suffix == ".diff"]
    assert diffs, f"No patch_*.diff file found in {repo_root}"
    return sorted(diffs)


@pytest.fixture(scope="session")
def patch_targets(patch_files: list[Path]) -> dict[Path, list[str]]:
    unidiff = importlib.import_module("unidiff")

    targets: dict[Path, list[str]] = {}
    for diff_file in patch_files:
        patch_set = unidiff.PatchSet.from_filename(str(diff_file))
        changed = [
            str(patched.path)
            for patched in patch_set
            if getattr(patched, "path", None)
        ]
        targets[diff_file] = changed
    return targets


def _read_repo_file(repo_root: Path, relative_path: Path) -> str:
    target = repo_root / relative_path
    assert target.exists(), f"{relative_path} does not exist"
    return target.read_text(encoding="utf-8")


def test_note_exists():
    note_path = GITHUB_ACTIONS_BUILD_PATH / "failed" / "failed_reasons.txt"
    assert note_path.exists(), "failed_reasons.txt does not exist"
    content = note_path.read_text(encoding="utf-8").strip()
    assert content, "failed_reasons.txt is empty"


def test_diff_exists(patch_files: list[Path]):
    unidiff = importlib.import_module("unidiff")

    for diff_file in patch_files:
        assert diff_file.stat().st_size > 0, f"{diff_file.name} is empty"
        try:
            unidiff.PatchSet.from_filename(str(diff_file))
        except unidiff.errors.UnidiffParseError as exc:
            raise AssertionError(f"{diff_file.name} is not a valid unified diff: {exc}") from exc


def test_build_success(build_artifacts: BuildArtifacts):
    if build_artifacts.returncode != 0:
        print("Build failed in the passed job")
        print(build_artifacts.stdout)
    assert build_artifacts.returncode == 0, "Build failed in the passed job"


def _assert_expected_env_was_executed(build_artifacts: BuildArtifacts, env_name: str) -> None:
    assert env_name in build_artifacts.env_statuses, f"{env_name} did not appear in build output"


def _assert_expected_env_collected_all_repo_tests(build_artifacts: BuildArtifacts, env_name: str) -> None:
    assert build_artifacts.collected_items.get(env_name) == 10, (
        f"{env_name} should collect 10 repository tests, got {build_artifacts.collected_items.get(env_name)}"
    )


def _assert_expected_env_finished_cleanly(build_artifacts: BuildArtifacts, env_name: str) -> None:
    assert build_artifacts.env_statuses.get(env_name) == "OK", (
        f"{env_name} did not finish cleanly: {build_artifacts.env_statuses.get(env_name)}"
    )


def _assert_non_target_python_env_is_explicitly_skipped(
    build_artifacts: BuildArtifacts,
    env_name: str,
) -> None:
    assert build_artifacts.env_statuses.get(env_name) == "SKIP", (
        f"{env_name} should be explicitly skipped in BugSwarm reproduction"
    )


def _assert_repo_test_file_passed_in_env(
    build_artifacts: BuildArtifacts,
    env_name: str,
    test_file: str,
) -> None:
    observed = build_artifacts.file_statuses.get(env_name, {}).get(test_file)
    assert observed == "pass", f"{test_file} did not pass in {env_name}: observed={observed}"


def _assert_exact_repo_test_set_observed(build_artifacts: BuildArtifacts, env_name: str) -> None:
    observed = set(build_artifacts.file_statuses.get(env_name, {}))
    assert observed == set(EXPECTED_TEST_FILES), (
        f"{env_name} observed repo test set mismatch: {sorted(observed)}"
    )


def _safe_test_suffix(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]+", "_", value).strip("_")


for _env_name in EXPECTED_ENVS:
    def _make_env_executed_test(env_name: str):
        def _test(build_artifacts: BuildArtifacts):
            _assert_expected_env_was_executed(build_artifacts, env_name)

        return _test

    def _make_env_collected_test(env_name: str):
        def _test(build_artifacts: BuildArtifacts):
            _assert_expected_env_collected_all_repo_tests(build_artifacts, env_name)

        return _test

    def _make_env_clean_test(env_name: str):
        def _test(build_artifacts: BuildArtifacts):
            _assert_expected_env_finished_cleanly(build_artifacts, env_name)

        return _test

    def _make_exact_file_set_test(env_name: str):
        def _test(build_artifacts: BuildArtifacts):
            _assert_exact_repo_test_set_observed(build_artifacts, env_name)

        return _test

    globals()[f"test_expected_env_was_executed_{_safe_test_suffix(_env_name)}"] = _make_env_executed_test(_env_name)
    globals()[f"test_expected_env_collected_all_repo_tests_{_safe_test_suffix(_env_name)}"] = _make_env_collected_test(_env_name)
    globals()[f"test_expected_env_finished_cleanly_{_safe_test_suffix(_env_name)}"] = _make_env_clean_test(_env_name)
    globals()[f"test_expected_repo_test_set_observed_{_safe_test_suffix(_env_name)}"] = _make_exact_file_set_test(_env_name)

for _env_name in EXPECTED_ENVS:
    for _test_file in EXPECTED_TEST_FILES:
        def _make_repo_test(env_name: str, test_file: str):
            def _test(build_artifacts: BuildArtifacts):
                _assert_repo_test_file_passed_in_env(build_artifacts, env_name, test_file)

            return _test

        globals()[
            f"test_repo_test_file_passed_in_env_{_safe_test_suffix(_env_name)}_{_safe_test_suffix(_test_file)}"
        ] = _make_repo_test(_env_name, _test_file)


def test_patch_targets_do_not_modify_repo_tests(patch_targets: dict[Path, list[str]]):
    for diff_file, changed_paths in patch_targets.items():
        bad = [path for path in changed_paths if path.startswith("tests/")]
        assert not bad, f"{diff_file.name} modifies repository tests instead of fixing production code: {bad}"


def test_patch_targets_do_not_modify_docs_or_assets(patch_targets: dict[Path, list[str]]):
    for diff_file, changed_paths in patch_targets.items():
        bad = [
            path
            for path in changed_paths
            if path in DISALLOWED_PATCH_TARGETS or path.startswith(DISALLOWED_PATCH_TARGET_PREFIXES)
        ]
        assert not bad, f"{diff_file.name} modifies low-signal docs/assets instead of code: {bad}"


def test_patch_targets_include_production_python_files(patch_targets: dict[Path, list[str]]):
    changed_paths = {path for paths in patch_targets.values() for path in paths}
    python_targets = [path for path in changed_paths if path.startswith("agentops/") and path.endswith(".py")]
    assert python_targets, f"Expected at least one production Python file to change, got {sorted(changed_paths)}"


def test_patch_targets_touch_event_or_client_logic(patch_targets: dict[Path, list[str]]):
    changed_paths = {path for paths in patch_targets.values() for path in paths}
    assert any(path in {str(EVENT_FILE), str(CLIENT_FILE)} for path in changed_paths), (
        f"Expected patch to touch {EVENT_FILE} or {CLIENT_FILE}, got {sorted(changed_paths)}"
    )


def test_event_file_exists(repo_root: Path):
    assert (repo_root / EVENT_FILE).exists(), f"{EVENT_FILE} does not exist"


def test_client_file_exists(repo_root: Path):
    assert (repo_root / CLIENT_FILE).exists(), f"{CLIENT_FILE} does not exist"


def test_event_init_timestamp_still_uses_iso_default(repo_root: Path):
    content = _read_repo_file(repo_root, EVENT_FILE)
    assert re.search(r"init_timestamp\s*:\s*.*field\(default_factory=get_ISO_time\)", content), (
        "Event.init_timestamp should still default from get_ISO_time"
    )


def test_client_record_updates_plain_event_end_timestamp(repo_root: Path):
    content = _read_repo_file(repo_root, CLIENT_FILE)
    assert "if isinstance(event, Event):" in content, "Client.record should handle plain Event values explicitly"
    assert "event.end_timestamp = get_ISO_time()" in content, (
        "Client.record should stamp end_timestamp when recording an Event"
    )


def test_client_record_updates_error_event_trigger_timestamp(repo_root: Path):
    content = _read_repo_file(repo_root, CLIENT_FILE)
    assert "elif isinstance(event, ErrorEvent):" in content, "Client.record should handle ErrorEvent separately"
    assert "event.trigger_event.end_timestamp = get_ISO_time()" in content, (
        "Client.record should stamp ErrorEvent.trigger_event end_timestamp"
    )


def test_patch_targets_only_touch_agentops_python_modules(patch_targets: dict[Path, list[str]]):
    changed_paths = {path for paths in patch_targets.values() for path in paths}
    python_targets = [path for path in changed_paths if path.endswith(".py")]
    assert python_targets, "Expected at least one Python source file in the patch"
    assert all(path.startswith("agentops/") for path in python_targets), (
        f"Patch should stay focused on agentops Python modules, got {sorted(python_targets)}"
    )


def test_patch_targets_avoid_packaging_or_dependency_guessing(patch_targets: dict[Path, list[str]]):
    changed_paths = {path for paths in patch_targets.values() for path in paths}
    disallowed = {
        "pyproject.toml",
        "setup.py",
        "setup.cfg",
        "requirements.txt",
        "requirements-dev.txt",
        "tox.ini",
    }
    assert not (changed_paths & disallowed), (
        f"Patch should not rely on broad packaging/dependency edits: {sorted(changed_paths & disallowed)}"
    )


def test_patch_targets_keep_code_surface_small(patch_targets: dict[Path, list[str]]):
    changed_paths = {path for paths in patch_targets.values() for path in paths}
    python_targets = [path for path in changed_paths if path.startswith("agentops/") and path.endswith(".py")]
    assert len(python_targets) <= 3, f"Patch should stay focused on a small Python surface, got {python_targets}"


def test_py311_core_regression_cluster_passes(build_artifacts: BuildArtifacts):
    observed = build_artifacts.file_statuses.get("py311", {})
    expected = {
        "tests/test_events.py",
        "tests/test_record_function.py",
        "tests/test_session.py",
    }
    missing = [path for path in expected if observed.get(path) != "pass"]
    assert not missing, f"py311 should pass the core regression cluster, missing={missing}"


def test_py311_stateful_session_cluster_passes(build_artifacts: BuildArtifacts):
    observed = build_artifacts.file_statuses.get("py311", {})
    expected = {"tests/test_session.py", "tests/test_teardown.py"}
    missing = [path for path in expected if observed.get(path) != "pass"]
    assert not missing, f"py311 should pass the stateful session cluster, missing={missing}"


def test_py311_event_and_record_function_pass(build_artifacts: BuildArtifacts):
    observed = build_artifacts.file_statuses.get("py311", {})
    expected = {"tests/test_events.py", "tests/test_record_function.py"}
    missing = [path for path in expected if observed.get(path) != "pass"]
    assert not missing, f"py311 should pass event and record-function checks, missing={missing}"


def test_client_record_handles_both_plain_and_error_events(repo_root: Path):
    content = _read_repo_file(repo_root, CLIENT_FILE)
    assert "if isinstance(event, Event):" in content, "Client.record should handle plain Event values explicitly"
    assert "elif isinstance(event, ErrorEvent):" in content, "Client.record should handle ErrorEvent values explicitly"


def test_client_record_updates_end_timestamps_in_all_paths(repo_root: Path):
    content = _read_repo_file(repo_root, CLIENT_FILE)
    assert "event.end_timestamp = get_ISO_time()" in content, (
        "Client.record should stamp end_timestamp for plain Event paths"
    )
    assert "event.trigger_event.end_timestamp = get_ISO_time()" in content, (
        "Client.record should stamp end_timestamp for ErrorEvent trigger paths"
    )


def test_build_output_does_not_report_failing_repo_tests(build_artifacts: BuildArtifacts):
    lowered = build_artifacts.stdout.lower()
    assert "test_record_timestamp" not in lowered, "Known failing repository test still appears in verifier output"


def test_build_output_does_not_report_failed_repo_tests(build_artifacts: BuildArtifacts):
    failure_markers = [
        "failed tests/test_events.py",
        "failed tests/test_session.py",
        "error collecting",
    ]
    lowered = build_artifacts.stdout.lower()
    assert not any(marker in lowered for marker in failure_markers), (
        "Build output still contains repository failure markers"
    )
