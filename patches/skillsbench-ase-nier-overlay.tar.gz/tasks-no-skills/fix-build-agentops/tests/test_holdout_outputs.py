from __future__ import annotations

import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

import pytest

GITHUB_ACTIONS_BUILD_PATH = Path("/home/github/build")
EXPECTED_ENVS = ("py310", "py311")
EXPECTED_TEST_FILES = (
    "tests/test_canary.py",
    "tests/test_events.py",
    "tests/test_record_function.py",
    "tests/test_session.py",
    "tests/test_teardown.py",
)
FORBIDDEN_PATCH_PATHS = (
    "README.md",
    "logo.png",
    "tests/",
    "docs/",
    "requirements.txt",
    "tox.ini",
)
RUN_PASSED_TIMEOUT_SEC = 420
ENV_RUN_RE = re.compile(r"^(py\d+): commands\[0\]>", re.MULTILINE)
ENV_SUMMARY_RE = re.compile(r"^\s*(py\d+): (OK|FAIL|SKIP)\b", re.MULTILINE)
COLLECTED_RE = re.compile(r"collected\s+(\d+)\s+items")
TEST_FILE_RE = re.compile(r"^(tests/test_[^ ]+\.py)\s+([.FEsx]+)\s+\[\s*\d+%\]$")


@dataclass
class BuildArtifacts:
    returncode: int
    stdout: str
    collected_items: dict[str, int] = field(default_factory=dict)
    env_statuses: dict[str, str] = field(default_factory=dict)
    file_statuses: dict[str, dict[str, str]] = field(default_factory=dict)


def _copy_failed_to_passed() -> None:
    failed_dir = GITHUB_ACTIONS_BUILD_PATH / "failed"
    passed_dir = GITHUB_ACTIONS_BUILD_PATH / "passed"
    assert failed_dir.exists(), "failed/ directory does not exist"
    if passed_dir.exists():
        shutil.rmtree(passed_dir)
    shutil.copytree(failed_dir, passed_dir)


def _parse_build_stdout(stdout: str) -> BuildArtifacts:
    artifacts = BuildArtifacts(returncode=-1, stdout=stdout)
    current_env: str | None = None
    for raw_line in stdout.splitlines():
        line = raw_line.rstrip()
        run_match = ENV_RUN_RE.match(line)
        if run_match:
            current_env = run_match.group(1)
            artifacts.file_statuses.setdefault(current_env, {})
            continue
        summary_match = ENV_SUMMARY_RE.match(line)
        if summary_match:
            artifacts.env_statuses[summary_match.group(1)] = summary_match.group(2)
            continue
        if current_env is None:
            continue
        collected_match = COLLECTED_RE.search(line)
        if collected_match:
            artifacts.collected_items[current_env] = int(collected_match.group(1))
            continue
        file_match = TEST_FILE_RE.match(line.strip())
        if file_match:
            path = file_match.group(1)
            symbols = file_match.group(2)
            artifacts.file_statuses.setdefault(current_env, {})[path] = (
                "pass" if set(symbols) <= {"."} else "fail"
            )
    return artifacts


def _extract_patch_targets(patch_file: Path) -> list[str]:
    targets: list[str] = []
    for line in patch_file.read_text(encoding="utf-8", errors="ignore").splitlines():
        if not line.startswith("+++ b/"):
            continue
        path = line.replace("+++ b/", "", 1).strip()
        if path and path != "/dev/null":
            targets.append(path)
    return targets


@pytest.fixture(scope="session")
def build_artifacts() -> BuildArtifacts:
    _copy_failed_to_passed()
    result = subprocess.run(
        "bash run_passed.sh",
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        shell=True,
        cwd="/tests",
        text=True,
        timeout=RUN_PASSED_TIMEOUT_SEC,
    )
    artifacts = _parse_build_stdout(result.stdout or "")
    artifacts.returncode = result.returncode
    return artifacts


@pytest.fixture(scope="session")
def repo_root() -> Path:
    repo_id = (GITHUB_ACTIONS_BUILD_PATH / "failed").glob("*")
    first = next(repo_id, None)
    assert first is not None, "No failed repository directory found"
    return first


@pytest.fixture(scope="session")
def patch_targets(repo_root: Path) -> list[str]:
    diffs = sorted(
        item for item in repo_root.iterdir() if item.is_file() and item.name.startswith("patch_") and item.suffix == ".diff"
    )
    assert diffs, "No patch_*.diff files found"
    merged: list[str] = []
    for diff in diffs:
        merged.extend(_extract_patch_targets(diff))
    return sorted(set(merged))


def test_holdout_note_exists() -> None:
    note_path = GITHUB_ACTIONS_BUILD_PATH / "failed" / "failed_reasons.txt"
    assert note_path.exists()
    assert note_path.read_text(encoding="utf-8").strip()


def test_holdout_build_succeeds(build_artifacts: BuildArtifacts) -> None:
    assert build_artifacts.returncode == 0, build_artifacts.stdout


def test_holdout_expected_env_count(build_artifacts: BuildArtifacts) -> None:
    assert len(build_artifacts.env_statuses) >= 2


@pytest.mark.parametrize("env_name", EXPECTED_ENVS)
def test_holdout_expected_env_present(build_artifacts: BuildArtifacts, env_name: str) -> None:
    assert env_name in build_artifacts.env_statuses


@pytest.mark.parametrize("env_name", EXPECTED_ENVS)
def test_holdout_expected_env_ok(build_artifacts: BuildArtifacts, env_name: str) -> None:
    assert build_artifacts.env_statuses.get(env_name) == "OK"


@pytest.mark.parametrize("env_name", EXPECTED_ENVS)
def test_holdout_expected_env_collects_tests(build_artifacts: BuildArtifacts, env_name: str) -> None:
    assert build_artifacts.collected_items.get(env_name, 0) >= 10


@pytest.mark.parametrize("env_name", EXPECTED_ENVS)
@pytest.mark.parametrize("test_file", EXPECTED_TEST_FILES)
def test_holdout_expected_repo_tests_pass(
    build_artifacts: BuildArtifacts,
    env_name: str,
    test_file: str,
) -> None:
    observed = build_artifacts.file_statuses.get(env_name, {}).get(test_file)
    assert observed == "pass", f"{env_name} {test_file} observed={observed}"


@pytest.mark.parametrize("forbidden", FORBIDDEN_PATCH_PATHS)
def test_holdout_patch_avoids_forbidden_paths(
    patch_targets: list[str],
    forbidden: str,
) -> None:
    if forbidden.endswith("/"):
        assert not any(path.startswith(forbidden) for path in patch_targets)
        return
    assert forbidden not in patch_targets


@pytest.mark.parametrize(
    "marker",
    (
        "if isinstance(event, Event):",
        "elif isinstance(event, ErrorEvent):",
        "event.end_timestamp = get_ISO_time()",
        "event.trigger_event.end_timestamp = get_ISO_time()",
        "init_timestamp",
        "default_factory=get_ISO_time",
        "class Event(",
        "class ErrorEvent(",
    ),
)
def test_holdout_core_timestamp_logic_markers(repo_root: Path, marker: str) -> None:
    target_paths = [
        repo_root / "agentops" / "event.py",
        repo_root / "agentops" / "client.py",
    ]
    content = "\n".join(path.read_text(encoding="utf-8") for path in target_paths if path.exists())
    assert marker in content


@pytest.mark.parametrize(
    "stdout_marker",
    (
        "py310: commands[0]",
        "py311: commands[0]",
        "tests/test_events.py",
        "tests/test_record_function.py",
        "tests/test_session.py",
        "tests/test_teardown.py",
    ),
)
def test_holdout_stdout_contains_expected_markers(
    build_artifacts: BuildArtifacts,
    stdout_marker: str,
) -> None:
    assert stdout_marker in build_artifacts.stdout


def test_holdout_patch_touches_agentops_python(patch_targets: list[str]) -> None:
    assert any(path.startswith("agentops/") and path.endswith(".py") for path in patch_targets)
