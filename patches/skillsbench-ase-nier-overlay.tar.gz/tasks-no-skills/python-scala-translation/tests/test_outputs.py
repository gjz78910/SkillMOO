#!/usr/bin/env python3
"""
Verifier tests for the Scala tokenizer translation task.

The old verifier over-relied on style heuristics and regex-presence checks.
This version keeps compilation and Scala unit-test gates, but adds denser
behavior checks through a generated Scala probe plus targeted source-structure
checks. The goal is to distinguish partial translations from semantically
faithful ones.
"""

from __future__ import annotations

import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

import pytest

TEST_SCALA_FILE = Path("Tokenizer.scala")
TEST_BUILD_FILE = Path("build.sbt")
TEST_SPEC_FILE = Path("TokenizerSpec.scala")
TEST_PROJECT_DIR = Path("localtest")
PROJECT_MAIN_DIR = TEST_PROJECT_DIR / "src" / "main" / "scala" / "tokenizer"
PROJECT_TEST_DIR = TEST_PROJECT_DIR / "src" / "test" / "scala" / "tokenizer"
PROBE_FILE = PROJECT_MAIN_DIR / "VerifierProbe.scala"
MIN_SCALA_TEST_TOTAL = 10
REQUIRED_COMPONENTS = {
    "TokenType": r"(sealed\s+trait|enum)\s+TokenType",
    "Token": r"(case\s+class|class)\s+Token",
    "TokenContainer": r"(case\s+class|class)\s+TokenContainer",
    "BaseTokenizer": r"(abstract\s+class|trait)\s+BaseTokenizer",
    "StringTokenizer": r"class\s+StringTokenizer",
    "NumericTokenizer": r"class\s+NumericTokenizer",
    "TemporalTokenizer": r"class\s+TemporalTokenizer",
    "UniversalTokenizer": r"class\s+UniversalTokenizer",
    "WhitespaceTokenizer": r"class\s+WhitespaceTokenizer",
    "JsonTokenizer": r"class\s+JsonTokenizer",
    "TokenRegistry": r"class\s+TokenRegistry",
    "TokenFunctor": r"class\s+TokenFunctor",
    "TokenizerBuilder": r"class\s+TokenizerBuilder",
}
REQUIRED_METHODS = {
    "tokenize": r"def\s+tokenize\s*[\(\[]",
    "tokenizeBatch": r"def\s+tokenizeBatch\s*[\(\[]",
    "withMetadata": r"def\s+withMetadata\s*[\(\[]",
    "register": r"def\s+register\s*[\(\[]",
    "process": r"def\s+process\s*[\(\[]",
    "map": r"def\s+map\s*[\(\[]",
}
PROBE_SOURCE = """package tokenizer

import java.time.{LocalDate, LocalDateTime}
import io.circe.Json
import io.circe.parser.parse

object VerifierProbe {
  private def emit(key: String, value: Any): Unit = {
    val rendered = Option(value).map(_.toString.replace("\\n", "\\\\n")).getOrElse("null")
    println(s"PROBE|$key|$rendered")
  }

  def main(args: Array[String]): Unit = {
    val baseToken = Token("test", TokenType.STRING)
    val tokenWithMeta = baseToken.withMetadata("kind" -> "demo")
    emit("token_type_string_value", TokenType.STRING.value)
    emit("token_original_metadata_size", baseToken.metadata.size)
    emit("token_metadata_value", tokenWithMeta.metadata("kind"))

    val container = new TokenContainer(Seq("a", "b", "c"))
    emit("container_size", container.size)
    emit("container_items", container.getAll.mkString(","))

    val stringToken = new StringTokenizer().tokenize("Hello")
    emit("string_value", stringToken.value)
    emit("string_type", stringToken.tokenType.value)

    val normalizedToken = new StringTokenizer(normalizer = _.trim.toLowerCase).tokenize("  Hello  ")
    emit("string_normalized", normalizedToken.value)

    val numericInt = new NumericTokenizer().tokenize(42)
    emit("numeric_int_value", numericInt.value)
    emit("numeric_int_type", numericInt.tokenType.value)

    val numericDouble = new NumericTokenizer(precision = 2).tokenize(3.14159)
    emit("numeric_double_value", numericDouble.value)

    val temporalDate = new TemporalTokenizer().tokenize(LocalDate.of(2024, 1, 15))
    emit("temporal_date_value", temporalDate.value)

    val temporalDateTime = new TemporalTokenizer().tokenize(LocalDateTime.of(2024, 1, 15, 10, 30, 0))
    emit("temporal_datetime_value", temporalDateTime.value)

    val universal = new UniversalTokenizer()
    emit("universal_null_value", universal.tokenizeNull.value)
    emit("universal_null_type", universal.tokenizeNull.tokenType.value)
    emit("universal_string_type", universal.tokenize("abc").tokenType.value)
    emit("universal_numeric_type", universal.tokenize(7).tokenType.value)
    emit("universal_temporal_type", universal.tokenize(LocalDate.of(2024, 1, 15)).tokenType.value)

    val whitespace = new WhitespaceTokenizer(lowercase = true, minLength = 2, maxLength = Some(4), stripPunctuation = true)
      .tokenize("A, Hello! WORLD...")
    emit("whitespace_values", whitespace.map(_.value).mkString(","))
    emit("whitespace_count", whitespace.size)

    val registry = new TokenRegistry[String]
    registry.register("demo", new TokenContainer(Seq("hello", "world")))
    registry.addHandler { s => Some(Token(s.toUpperCase, TokenType.STRING)) }
    emit("registry_processed_values", registry.process("demo").flatten.map(_.value).mkString(","))
    emit("registry_missing_size", registry.process("missing").size)

    val jsonToken = new JsonTokenizer().tokenize(parse("{\\"key\\":\\"value\\"}").getOrElse(Json.Null))
    emit("json_token_type", jsonToken.tokenType.value)
    emit("json_token_contains_key", jsonToken.value.contains("key"))

    val functor = new TokenFunctor(5).map(_ * 2)
    emit("functor_value", functor.get)

    val built = TokenizerBuilder[String]()
      .withNormalizer(_.toLowerCase)
      .withNormalizer(_.replace(" ", "_"))
      .withValidator(_.nonEmpty)
      .withMetadata("type" -> "custom")
      .build()
    val builtToken = built("Hello World")
    emit("builder_value", builtToken.value)
    emit("builder_metadata_type", builtToken.metadata("type"))
  }
}
"""


@dataclass
class CommandResult:
    success: bool
    output: str
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    __test__ = False


@dataclass
class TestResult:
    passed: int = 0
    failed: int = 0
    total: int = 0
    output: str = ""
    errors: list[str] = field(default_factory=list)

    __test__ = False


def _run(command: list[str], *, cwd: Path, timeout: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )


def _write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _prepare_project() -> None:
    if TEST_PROJECT_DIR.exists():
        shutil.rmtree(TEST_PROJECT_DIR)
    PROJECT_MAIN_DIR.mkdir(parents=True, exist_ok=True)
    PROJECT_TEST_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy(TEST_SCALA_FILE, PROJECT_MAIN_DIR / "Tokenizer.scala")
    shutil.copy(TEST_BUILD_FILE, TEST_PROJECT_DIR / "build.sbt")
    shutil.copy(TEST_SPEC_FILE, PROJECT_TEST_DIR / "TokenizerSpec.scala")
    _write_text(PROBE_FILE, PROBE_SOURCE)


def _extract_errors(output: str) -> list[str]:
    lines = []
    for line in output.splitlines():
        lowered = line.lower()
        if "[error]" in lowered or " error " in lowered:
            lines.append(line.strip())
    return lines[:10]


def _parse_test_result(output: str) -> TestResult:
    result = TestResult(output=output)
    patterns = [
        re.search(r"(\d+)\s+tests?\s+succeeded", output, re.IGNORECASE),
        re.search(r"Tests:\s+succeeded\s+(\d+),\s+failed\s+(\d+)", output),
    ]
    if patterns[0]:
        result.passed = int(patterns[0].group(1))
    if patterns[1]:
        result.passed = int(patterns[1].group(1))
        result.failed = int(patterns[1].group(2))
    failed_match = re.search(r"(\d+)\s+tests?\s+failed", output, re.IGNORECASE)
    if failed_match:
        result.failed = int(failed_match.group(1))
    total_match = re.search(r"(\d+)\s+tests?\s+were", output, re.IGNORECASE)
    if total_match:
        result.total = int(total_match.group(1))
    else:
        result.total = result.passed + result.failed
    result.errors = _extract_errors(output)
    return result


def _load_source() -> str:
    assert TEST_SCALA_FILE.exists(), f"{TEST_SCALA_FILE} does not exist"
    return TEST_SCALA_FILE.read_text(encoding="utf-8")


@pytest.fixture(scope="session")
def source_text() -> str:
    return _load_source()


@pytest.fixture(scope="session")
def compilation_result() -> CommandResult:
    assert shutil.which("sbt"), "sbt is not available in the verifier environment"
    _prepare_project()
    proc = _run(["sbt", "compile"], cwd=TEST_PROJECT_DIR, timeout=300)
    output = proc.stdout + proc.stderr
    return CommandResult(success=proc.returncode == 0, output=output, errors=_extract_errors(output))


@pytest.fixture(scope="session")
def unit_test_result(compilation_result: CommandResult) -> TestResult:
    if not compilation_result.success:
        pytest.skip("Compilation failed; Scala unit-test diagnostics unavailable")
    proc = _run(["sbt", "test"], cwd=TEST_PROJECT_DIR, timeout=600)
    return _parse_test_result(proc.stdout + proc.stderr)


@pytest.fixture(scope="session")
def probe_results(compilation_result: CommandResult) -> dict[str, str]:
    if not compilation_result.success:
        pytest.skip("Compilation failed; runtime probe unavailable")
    proc = _run(["sbt", "runMain", "tokenizer.VerifierProbe"], cwd=TEST_PROJECT_DIR, timeout=300)
    output = proc.stdout + proc.stderr
    assert proc.returncode == 0, f"Verifier probe failed: {output}"
    results: dict[str, str] = {}
    for line in output.splitlines():
        if not line.startswith("PROBE|"):
            continue
        _, key, value = line.split("|", 2)
        results[key] = value
    assert results, "Verifier probe produced no structured output"
    return results


def test_compilation_succeeds(compilation_result: CommandResult):
    assert compilation_result.success, f"Compilation failed: {compilation_result.errors[:5]}"


def test_unit_test_suite_runs(unit_test_result: TestResult):
    assert unit_test_result.total >= MIN_SCALA_TEST_TOTAL, (
        f"Expected at least {MIN_SCALA_TEST_TOTAL} Scala tests, got {unit_test_result.total}"
    )


def test_unit_test_suite_has_no_failures(unit_test_result: TestResult):
    assert unit_test_result.failed == 0, f"Scala unit tests failed: {unit_test_result.errors[:5]}"


def _assert_pattern(source_text: str, pattern: str, message: str) -> None:
    assert re.search(pattern, source_text), message


def _assert_no_pattern(source_text: str, pattern: str, message: str) -> None:
    assert not re.search(pattern, source_text), message


def _safe_test_suffix(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]+", "_", value).strip("_")


for _component_name, _pattern in REQUIRED_COMPONENTS.items():
    def _make_component_test(component_name: str, pattern: str):
        def _test(source_text: str):
            _assert_pattern(source_text, pattern, f"Missing required component: {component_name}")

        return _test

    globals()[f"test_required_component_present_{_safe_test_suffix(_component_name)}"] = _make_component_test(_component_name, _pattern)


for _method_name, _pattern in REQUIRED_METHODS.items():
    def _make_method_test(method_name: str, pattern: str):
        def _test(source_text: str):
            _assert_pattern(source_text, pattern, f"Missing required method: {method_name}")

        return _test

    globals()[f"test_required_method_present_{_safe_test_suffix(_method_name)}"] = _make_method_test(_method_name, _pattern)


PROBE_EXPECTATIONS = {
    "token_type_string_value": "string",
    "token_original_metadata_size": "0",
    "token_metadata_value": "demo",
    "container_size": "3",
    "container_items": "a,b,c",
    "string_normalized": "hello",
    "numeric_int_value": "42",
    "numeric_int_type": "numeric",
    "universal_string_type": "string",
    "universal_numeric_type": "numeric",
    "registry_processed_values": "HELLO,WORLD",
    "registry_missing_size": "0",
    "json_token_type": "structured",
    "json_token_contains_key": "true",
    "functor_value": "10",
    "builder_value": "hello_world",
    "builder_metadata_type": "custom",
}


for _probe_key, _expected in PROBE_EXPECTATIONS.items():
    def _make_probe_test(probe_key: str, expected: str):
        def _test(probe_results: dict[str, str]):
            assert probe_results.get(probe_key) == expected, (
                f"Unexpected probe output for {probe_key}: {probe_results.get(probe_key)!r}"
            )

        return _test

    globals()[f"test_probe_behavior_{_safe_test_suffix(_probe_key)}"] = _make_probe_test(_probe_key, _expected)


def test_source_registry_pipeline_is_present(source_text: str):
    _assert_pattern(source_text, r"class\s+TokenRegistry", "TokenRegistry should be implemented")
    _assert_pattern(source_text, r"def\s+register\s*[\(\[]", "TokenRegistry should expose register")
    _assert_pattern(source_text, r"def\s+process\s*[\(\[]", "TokenRegistry should expose process")
